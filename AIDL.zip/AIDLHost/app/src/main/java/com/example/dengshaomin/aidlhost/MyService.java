package com.example.dengshaomin.aidlhost;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

import com.example.dengshaomin.aidlhost.aidl.IMyAidlInterface;
import com.example.dengshaomin.aidlhost.aidl.Person;

/**
 * Created by dengshaomin on 2017/8/17.
 */

public class MyService extends Service {
    public MyService() {

    }

    @Override
    public IBinder onBind(Intent intent) {
        return new MyBinder();
    }

    class MyBinder extends IMyAidlInterface.Stub {

        @Override
        public void basicTypes(int anInt, long aLong, boolean aBoolean, float aFloat, double aDouble, String aString) throws RemoteException {

        }

        @Override
        public String getName() throws RemoteException {
            return "nothing";
        }

        @Override
        public Person getPerson() throws RemoteException {
            Person person  = new Person();
            person.setName("nothing");
            person.setMale(false);
            person.setAge(12);
            return person;
        }
    }
}
