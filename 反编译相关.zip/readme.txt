http://blog.csdn.net/guolin_blog/article/details/49738023/
http://blog.csdn.net/guolin_blog/article/details/50451259