/** Automatically generated file. DO NOT MODIFY */
package com.duguang.baseanimation;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}