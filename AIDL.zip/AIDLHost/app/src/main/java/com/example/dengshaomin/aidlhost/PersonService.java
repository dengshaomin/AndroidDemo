package com.example.dengshaomin.aidlhost;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

import com.example.dengshaomin.aidlhost.aidl.IPerson;
import com.example.dengshaomin.aidlhost.aidl.Person;

/**
 * Created by dengshaomin on 2017/8/17.
 */

public class PersonService extends Service {
    public PersonService() {

    }

    @Override
    public IBinder onBind(Intent intent) {
        return new PersonService.MyBinder();
    }

    class MyBinder extends IPerson.Stub {

        @Override
        public void basicTypes(int anInt, long aLong, boolean aBoolean, float aFloat, double aDouble, String aString) throws RemoteException {

        }

        @Override
        public Person getPerson() throws RemoteException {
            Person person = new Person();
            person.setAge(20);
            person.setMale(true);
            person.setName("code");

            return person;
        }
    }
}
